import { createContext } from "react";

export const MovieContext = createContext();
