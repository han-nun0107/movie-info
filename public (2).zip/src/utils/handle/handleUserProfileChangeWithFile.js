import { toast } from "react-toastify";
import supabase from "../../../supabaseClient";

export const handleChangeImage = async (
  uploadImg,
  setUserInfo,
  userInfo,
  setChangeImg
) => {
  if (uploadImg.trim() === "") {
    toast.warn("사진을 선택 해주세요", { toastId: "ChangeImg" });
    return;
  }
  const { error } = await supabase.auth.updateUser({
    data: { avatar_url: uploadImg },
  });
  if (error) {
    console.error("이미지 변경 실패", error);
  }
  setUserInfo({ ...userInfo, avatar_url: uploadImg });
  setChangeImg("");
};

export const handleUserProfileChange = (e, { setUploadImg }) => {
  const { files } = e.target;
  const uploadFile = files[0];
  const reader = new FileReader();
  reader.readAsDataURL(uploadFile);
  reader.onloadend = () => {
    setUploadImg(reader.result);
  };
};
