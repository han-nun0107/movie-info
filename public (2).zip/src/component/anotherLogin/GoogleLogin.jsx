export default function GoogleLogin() {
  const handleGoogleLogin = async () => {};

  return (
    <button onClick={handleGoogleLogin} className="cursor-pointer bg-gray-500">
      구글 로그인
    </button>
  );
}
